﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OAuthenServices.Models
{
    public class BaseResponse<T>
    {
        /// <summary>
        /// 200: Success
        /// 400: Badrequest (param wrong)
        /// 401: UnAuthorize
        /// 403: Access denied
        /// 404: Not found
        /// 500: Server exception
        /// </summary>
        public int StatusCode { get; set; }
        public string Message { get; set; }
        public T Model { get; set; }
        public List<T> Models { get; set; }
    }
}

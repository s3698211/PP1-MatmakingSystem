﻿using Microsoft.EntityFrameworkCore;
using OAuthenServices.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OAuthenServices.DAL
{
    public class OAuthenContext : DbContext
    {
        // contructor to set opt for dbcontext
        public OAuthenContext(DbContextOptions<OAuthenContext> options) : base(options) { }

        public DbSet<Client> Clients { get; set; }
        public DbSet<User> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
    }
}

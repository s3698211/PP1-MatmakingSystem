﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace OAuthenServices.Extensions
{
    public class JWTHelpers
    {
        private readonly string _secret;
        private readonly string _expiration;
        private readonly string _audience;
        private readonly string _issuer;


        public JWTHelpers(IConfiguration configuration)
        {
            _secret = configuration.GetSection("JWT").GetSection("secret").Value;
            _expiration = configuration.GetSection("JWT").GetSection("expriration").Value;
            _audience = configuration.GetSection("JWT").GetSection("audience").Value;
            _issuer = configuration.GetSection("JWT").GetSection("issuer").Value;
        }

        public string GenerateToken(string email)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_secret);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[] { 
                    new Claim(ClaimTypes.Email, email)
                }),
                Audience = _audience,
                Issuer = _issuer,
                Expires = DateTime.Now.AddMinutes(int.Parse(_expiration)),
                SigningCredentials = new SigningCredentials(
                    new SymmetricSecurityKey(key),
                    SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);

            return tokenHandler.WriteToken(token);
        }
    }
}

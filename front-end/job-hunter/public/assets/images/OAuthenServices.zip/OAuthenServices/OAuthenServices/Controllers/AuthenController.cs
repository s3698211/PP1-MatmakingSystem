﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using OAuthenServices.DAL;
using OAuthenServices.Entities;
using OAuthenServices.Extensions;
using OAuthenServices.Models;
using OAuthenServices.Models.Authen;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OAuthenServices.Controllers
{
    [ApiController]
    [Authorize]
    [Route("[controller]")]
    public class AuthenController : ControllerBase
    {
        private readonly OAuthenContext _authContext;
        private readonly IConfiguration _config;

        public AuthenController(OAuthenContext authContext, IConfiguration config)
        {
            _authContext = authContext;
            _config = config;
        }

        /// <summary>
        /// Endpoint: ~/authen/login
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("login")]
        [AllowAnonymous]
        public async Task<BaseResponse<LoginResponse>> Login([FromBody]LoginRequest model)
        {
            // Todo: verify user name & password
            if (model.Username == "admin@seedsoft.com" && model.Password == "admin")
            {
                var jwt = new JWTHelpers(_config);

                return new BaseResponse<LoginResponse>()
                {
                    StatusCode = 200,
                    Message = "Login successfully",
                    Model = new LoginResponse()
                    {
                        Token = jwt.GenerateToken(model.Username),
                        UserInfo = new User()
                    }
                };
            }

            return new BaseResponse<LoginResponse>() {
                StatusCode = 401,
                Message = "User is not valid"
            };
        }

        [HttpGet("get-user-info")]
        public async Task<BaseResponse<User>> GetUserInfo([FromQuery]string id)
        {
            // Todo: get user info from db
            var user = new User();

            return new BaseResponse<User>()
            {
                Model = user
            };
        }
    }
}

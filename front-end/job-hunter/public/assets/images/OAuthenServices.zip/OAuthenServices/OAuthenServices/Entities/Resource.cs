﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OAuthenServices.Entities
{
    public class Resource
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
    }
}
